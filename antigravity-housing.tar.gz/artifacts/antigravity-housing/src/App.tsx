import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { Navbar } from "@/components/Navbar";
import { Home } from "@/pages/Home";
import { Login } from "@/pages/Login";
import { PropertyDetail } from "@/pages/PropertyDetail";
import { AddReview } from "@/pages/AddReview";
import { Moderator } from "@/pages/Moderator";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

setAuthTokenGetter(() => localStorage.getItem("auth_token"));

function AppRoutes() {
  return (
    <>
      <Navbar />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/properties/:id" component={PropertyDetail} />
        <Route path="/add-review/:propertyId" component={AddReview} />
        <Route path="/moderator" component={Moderator} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppRoutes />
          </WouterRouter>
          <Toaster
            position="top-right"
            theme="dark"
            richColors
          />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
