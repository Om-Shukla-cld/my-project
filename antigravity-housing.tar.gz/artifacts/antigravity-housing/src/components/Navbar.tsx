import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useLogout } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, LogOut, User, Home } from "lucide-react";
import { toast } from "sonner";

export function Navbar() {
  const { user, isAuthenticated, isModerator, logout } = useAuth();
  const logoutMutation = useLogout();
  const [, navigate] = useLocation();

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync({ data: {} } as any);
    } catch {
    }
    logout();
    toast.success("Logged out successfully");
    navigate("/");
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card/90 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer group">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Home className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg text-foreground group-hover:text-primary transition-colors">
                AntiGravity
              </span>
              <span className="text-muted-foreground text-sm hidden sm:block">Housing</span>
            </div>
          </Link>

          <div className="flex items-center gap-3">
            {isAuthenticated && isModerator && (
              <Link href="/moderator">
                <Button variant="ghost" size="sm" className="gap-2 text-primary">
                  <Shield className="w-4 h-4" />
                  <span className="hidden sm:block">Moderator</span>
                </Button>
              </Link>
            )}

            {isAuthenticated && user ? (
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                  <User className="w-3.5 h-3.5" />
                  <span className="font-mono font-medium text-foreground">{user.anonymousId}</span>
                  {isModerator && (
                    <Badge variant="outline" className="border-primary text-primary text-xs">
                      Mod
                    </Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="gap-2 text-muted-foreground hover:text-foreground"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:block">Logout</span>
                </Button>
              </div>
            ) : (
              <Link href="/login">
                <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Login
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
