import { Link } from "wouter";
import { motion } from "framer-motion";
import { MapPin, ChevronRight, BedDouble, School } from "lucide-react";
import { TrustBadge } from "./TrustBadge";
import { StarRating } from "./StarRating";
import { Badge } from "@/components/ui/badge";

interface Property {
  id: number;
  name: string;
  address: string;
  rent: number;
  rooms?: number | null;
  amenities: string[];
  images: string[];
  latitude?: number | null;
  longitude?: number | null;
  distanceFromCollege?: number | null;
  trustScore: number;
  trustLabel: string;
  averageRating: number;
  reviewCount: number;
  distanceFromUser?: number | null;
}

interface PropertyCardProps {
  property: Property;
  index?: number;
}

export function PropertyCard({ property, index = 0 }: PropertyCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.06 }}
      whileHover={{ y: -4 }}
      className="group"
    >
      <Link href={`/properties/${property.id}`}>
        <div className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-black/20">
          <div className="relative h-44 bg-gradient-to-br from-secondary to-muted overflow-hidden">
            {property.images && property.images.length > 0 ? (
              <img
                src={property.images[0]}
                alt={property.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <div className="w-12 h-12 bg-muted rounded-lg mx-auto mb-2 flex items-center justify-center">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <span className="text-xs">No image</span>
                </div>
              </div>
            )}
            <div className="absolute top-3 right-3">
              <TrustBadge score={property.trustScore} label={property.trustLabel} size="sm" />
            </div>
            {/* Distance from user badge */}
            {property.distanceFromUser != null && (
              <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-lg">
                {property.distanceFromUser < 1
                  ? `${Math.round(property.distanceFromUser * 1000)}m away`
                  : `${property.distanceFromUser.toFixed(1)} km away`}
              </div>
            )}
          </div>

          <div className="p-4">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="font-semibold text-foreground text-sm leading-tight line-clamp-1 group-hover:text-primary transition-colors">
                {property.name}
              </h3>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0 mt-0.5" />
            </div>

            <div className="flex items-center gap-1 text-muted-foreground text-xs mb-2">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="line-clamp-1">{property.address}</span>
            </div>

            {/* Rooms + College distance row */}
            <div className="flex items-center gap-3 mb-3 text-xs text-muted-foreground">
              {property.rooms != null && (
                <span className="flex items-center gap-1">
                  <BedDouble className="w-3 h-3" />
                  {property.rooms} {property.rooms === 1 ? "room" : "rooms"}
                </span>
              )}
              {property.distanceFromCollege != null && (
                <span className="flex items-center gap-1 text-amber-400/80">
                  <School className="w-3 h-3" />
                  {property.distanceFromCollege < 1
                    ? `${Math.round(property.distanceFromCollege * 1000)}m from VIT`
                    : `${property.distanceFromCollege} km from VIT`}
                </span>
              )}
            </div>

            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-xl font-bold text-primary">
                  ₹{property.rent.toLocaleString()}
                </span>
                <span className="text-muted-foreground text-xs">/mo</span>
              </div>
              <div className="flex items-center gap-1.5">
                <StarRating rating={Math.round(property.averageRating)} size="sm" />
                <span className="text-muted-foreground text-xs">
                  ({property.reviewCount})
                </span>
              </div>
            </div>

            {property.amenities && property.amenities.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {property.amenities.slice(0, 3).map((amenity) => (
                  <Badge
                    key={amenity}
                    variant="secondary"
                    className="text-xs px-2 py-0 bg-secondary/50 text-muted-foreground"
                  >
                    {amenity}
                  </Badge>
                ))}
                {property.amenities.length > 3 && (
                  <Badge
                    variant="secondary"
                    className="text-xs px-2 py-0 bg-secondary/50 text-muted-foreground"
                  >
                    +{property.amenities.length - 3}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
