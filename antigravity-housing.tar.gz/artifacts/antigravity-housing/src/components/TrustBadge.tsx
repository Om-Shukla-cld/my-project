import { cn } from "@/lib/utils";

interface TrustBadgeProps {
  score: number;
  label: string;
  size?: "sm" | "md" | "lg";
}

export function TrustBadge({ score, label, size = "md" }: TrustBadgeProps) {
  const colorClass =
    label === "Reliable"
      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
      : label === "Average"
      ? "bg-amber-500/20 text-amber-400 border-amber-500/40"
      : "bg-red-500/20 text-red-400 border-red-500/40";

  const sizeClass =
    size === "sm"
      ? "text-xs px-2 py-0.5"
      : size === "lg"
      ? "text-sm px-3 py-1.5 font-semibold"
      : "text-xs px-2.5 py-1";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border font-medium",
        colorClass,
        sizeClass
      )}
    >
      <span>{score}/100</span>
      <span className="text-current/70">·</span>
      <span>{label}</span>
    </span>
  );
}
