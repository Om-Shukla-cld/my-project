import { useState } from "react";
import { useParams, useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Shield, Eye } from "lucide-react";
import { useCreateReview, useGetProperty, getGetReviewsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { StarRating } from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

const reviewSchema = z.object({
  pros: z.string().min(10, "Pros must be at least 10 characters"),
  cons: z.string().min(10, "Cons must be at least 10 characters"),
  rentPaid: z.number().optional(),
});

type ReviewForm = z.infer<typeof reviewSchema>;

export function AddReview() {
  const { propertyId } = useParams<{ propertyId: string }>();
  const pId = parseInt(propertyId, 10);
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [rating, setRating] = useState(0);
  const queryClient = useQueryClient();

  const { data: property } = useGetProperty(pId, { query: { enabled: !!pId } });
  const createReview = useCreateReview();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ReviewForm>({ resolver: zodResolver(reviewSchema) });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-xl font-bold text-foreground mb-2">Login required</h2>
          <p className="text-muted-foreground text-sm mb-4">You must be logged in to write a review.</p>
          <Link href="/login">
            <Button className="bg-primary text-primary-foreground">Login</Button>
          </Link>
        </div>
      </div>
    );
  }

  const onSubmit = async (data: ReviewForm) => {
    if (rating === 0) {
      toast.error("Please select a rating before submitting.");
      return;
    }

    try {
      await createReview.mutateAsync({
        data: {
          propertyId: pId,
          rating,
          pros: data.pros,
          cons: data.cons,
          rentPaid: data.rentPaid,
        },
      });

      await queryClient.invalidateQueries({ queryKey: getGetReviewsQueryKey(pId) });

      toast.success("Review submitted! It will appear after moderation.");
      navigate(`/properties/${pId}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.error || "Failed to submit review. Please try again.");
    }
  };

  return (
    <div className="min-h-screen pt-20 px-4 pb-12">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Link href={`/properties/${pId}`}>
            <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="w-4 h-4" />
              Back to property
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Write a Review</h1>
          {property && (
            <p className="text-muted-foreground text-sm mt-1">
              {property.name} · {property.address}
            </p>
          )}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-6 flex items-start gap-3">
            <Shield className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-amber-400 text-sm font-medium">Your review is anonymous</p>
              <p className="text-muted-foreground text-xs mt-0.5">
                This review will be posted as{" "}
                <code className="text-foreground font-mono">{user?.anonymousId}</code>. Your real name and email are never shown.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="bg-card border border-border rounded-2xl p-6 space-y-6">
            {/* Star Rating */}
            <div>
              <Label className="text-sm text-muted-foreground block mb-3">
                Overall Rating <span className="text-red-400">*</span>
              </Label>
              <div className="flex items-center gap-3">
                <StarRating
                  rating={rating}
                  size="lg"
                  interactive
                  onChange={setRating}
                />
                <span className="text-foreground font-medium">
                  {rating === 0 ? "Select rating" : ["", "Poor", "Fair", "Good", "Very Good", "Excellent"][rating]}
                </span>
              </div>
            </div>

            {/* Pros */}
            <div>
              <Label className="text-sm text-muted-foreground block mb-2">
                Pros — What do you like? <span className="text-red-400">*</span>
              </Label>
              <Textarea
                {...register("pros")}
                placeholder="e.g. Great WiFi speed, food quality is excellent, very clean bathrooms..."
                className="bg-secondary/50 border-border min-h-[100px] resize-none"
              />
              {errors.pros && (
                <p className="text-red-400 text-xs mt-1">{errors.pros.message}</p>
              )}
            </div>

            {/* Cons */}
            <div>
              <Label className="text-sm text-muted-foreground block mb-2">
                Cons — What could be better? <span className="text-red-400">*</span>
              </Label>
              <Textarea
                {...register("cons")}
                placeholder="e.g. AC doesn't work well in summer, power cuts during exams..."
                className="bg-secondary/50 border-border min-h-[100px] resize-none"
              />
              {errors.cons && (
                <p className="text-red-400 text-xs mt-1">{errors.cons.message}</p>
              )}
            </div>

            {/* Rent Paid */}
            <div>
              <Label className="text-sm text-muted-foreground block mb-2">
                Rent Paid (₹/month) — <span className="text-muted-foreground">Optional</span>
              </Label>
              <Input
                {...register("rentPaid", { valueAsNumber: true })}
                type="number"
                placeholder="e.g. 6500"
                className="bg-secondary/50 border-border max-w-xs"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <Button
                type="submit"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={createReview.isPending}
              >
                {createReview.isPending ? "Submitting..." : "Submit Review"}
              </Button>
              <Link href={`/properties/${pId}`}>
                <Button type="button" variant="ghost">Cancel</Button>
              </Link>
            </div>

            <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t border-border">
              <Eye className="w-3.5 h-3.5" />
              Reviews are reviewed by moderators before going live. This usually takes a few hours.
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
