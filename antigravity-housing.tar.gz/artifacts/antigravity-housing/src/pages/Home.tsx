import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Search, SlidersHorizontal, Building, Star, Shield, TrendingUp, X, Navigation, Loader2 } from "lucide-react";
import { useListProperties, useGetPropertyStats } from "@workspace/api-client-react";
import { PropertyCard } from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const AMENITY_OPTIONS = ["WiFi", "AC", "Food", "Gym", "Security", "Hot Water", "Power Backup", "Laundry", "Inverter", "Parking"];

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

type SortMode = "default" | "nearMe" | "nearCollege" | "rentAsc" | "rentDesc";

export function Home() {
  const [search, setSearch] = useState("");
  const [minRent, setMinRent] = useState<number | undefined>(undefined);
  const [maxRent, setMaxRent] = useState<number | undefined>(undefined);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [appliedSearch, setAppliedSearch] = useState("");
  const [appliedMin, setAppliedMin] = useState<number | undefined>(undefined);
  const [appliedMax, setAppliedMax] = useState<number | undefined>(undefined);
  const [appliedAmenities, setAppliedAmenities] = useState<string[]>([]);
  const [sortMode, setSortMode] = useState<SortMode>("default");
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);

  const { data: properties, isLoading } = useListProperties({
    search: appliedSearch || undefined,
    minRent: appliedMin,
    maxRent: appliedMax,
    amenities: appliedAmenities.length > 0 ? appliedAmenities.join(",") : undefined,
  });

  const { data: stats } = useGetPropertyStats();

  const handleSearch = () => {
    setAppliedSearch(search);
    setAppliedMin(minRent);
    setAppliedMax(maxRent);
    setAppliedAmenities(selectedAmenities);
  };

  const handleClearFilters = () => {
    setSearch("");
    setMinRent(undefined);
    setMaxRent(undefined);
    setSelectedAmenities([]);
    setAppliedSearch("");
    setAppliedMin(undefined);
    setAppliedMax(undefined);
    setAppliedAmenities([]);
    setSortMode("default");
    setUserLocation(null);
  };

  const handleNearMe = useCallback(() => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setSortMode("nearMe");
        setLocating(false);
        toast.success("Showing PGs nearest to you!");
      },
      () => {
        setLocating(false);
        toast.error("Could not get your location. Please allow location access.");
      },
      { timeout: 8000 }
    );
  }, []);

  const toggleAmenity = (a: string) => {
    setSelectedAmenities((prev) =>
      prev.includes(a) ? prev.filter((x) => x !== a) : [...prev, a]
    );
  };

  const hasActiveFilters =
    appliedSearch || appliedMin !== undefined || appliedMax !== undefined || appliedAmenities.length > 0;

  // Enrich properties with user distance and sort
  const enrichedProperties = properties?.map((p) => ({
    ...p,
    distanceFromUser:
      userLocation && p.latitude != null && p.longitude != null
        ? haversineKm(userLocation.lat, userLocation.lng, p.latitude!, p.longitude!)
        : null,
  }));

  const sortedProperties = enrichedProperties ? [...enrichedProperties].sort((a, b) => {
    if (sortMode === "nearMe") {
      const da = a.distanceFromUser ?? Infinity;
      const db = b.distanceFromUser ?? Infinity;
      return da - db;
    }
    if (sortMode === "nearCollege") {
      const da = a.distanceFromCollege ?? Infinity;
      const db = b.distanceFromCollege ?? Infinity;
      return (da as number) - (db as number);
    }
    if (sortMode === "rentAsc") return a.rent - b.rent;
    if (sortMode === "rentDesc") return b.rent - a.rent;
    return 0;
  }) : enrichedProperties;

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div
        className="relative min-h-[580px] flex flex-col items-center justify-center pt-16"
        style={{
          backgroundImage: "url(/college-bg.png)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/65 to-background" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative z-10 text-center px-4 max-w-4xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Badge className="mb-4 bg-primary/20 text-primary border-primary/30 text-xs font-medium px-3 py-1">
              VIT Student Housing Directory
            </Badge>
          </motion.div>

          <h1 className="text-3xl sm:text-5xl font-bold text-white leading-tight mb-4">
            Find Your Perfect{" "}
            <span className="text-primary">Student Housing</span>
            {" "}Near VIT
          </h1>
          <p className="text-white/70 text-base sm:text-lg mb-8 max-w-2xl mx-auto">
            Anonymous reviews from real VIT students. Trust scores you can rely on. No fake listings.
          </p>

          {/* Search bar */}
          <div className="bg-card/95 backdrop-blur-md rounded-2xl p-3 shadow-2xl max-w-2xl mx-auto border border-border/60">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search by name, area or location..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-9 border-0 bg-secondary/50 focus-visible:ring-1 focus-visible:ring-primary"
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowFilters(!showFilters)}
                className={showFilters ? "text-primary" : "text-muted-foreground"}
                title="Filters"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </Button>
              <Button onClick={handleSearch} className="bg-primary text-primary-foreground hover:bg-primary/90 px-6">
                Search
              </Button>
            </div>

            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 pt-3 border-t border-border space-y-3"
              >
                <div className="flex gap-3">
                  <div className="flex-1">
                    <label className="text-xs text-muted-foreground block mb-1">Min Rent (₹)</label>
                    <Input
                      type="number"
                      placeholder="e.g. 4000"
                      value={minRent ?? ""}
                      onChange={(e) => setMinRent(e.target.value ? Number(e.target.value) : undefined)}
                      className="border-0 bg-secondary/50 text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="text-xs text-muted-foreground block mb-1">Max Rent (₹)</label>
                    <Input
                      type="number"
                      placeholder="e.g. 10000"
                      value={maxRent ?? ""}
                      onChange={(e) => setMaxRent(e.target.value ? Number(e.target.value) : undefined)}
                      className="border-0 bg-secondary/50 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Amenities</label>
                  <div className="flex flex-wrap gap-1.5">
                    {AMENITY_OPTIONS.map((a) => (
                      <button
                        key={a}
                        onClick={() => toggleAmenity(a)}
                        className={`text-xs px-3 py-1 rounded-full border transition-all ${
                          selectedAmenities.includes(a)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-secondary/50 text-muted-foreground border-border hover:border-primary/50"
                        }`}
                      >
                        {a}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Near Me button */}
          <div className="mt-4 flex justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={handleNearMe}
              disabled={locating}
              className={`gap-2 text-xs border-white/30 text-white/80 hover:bg-white/10 hover:text-white ${sortMode === "nearMe" ? "bg-primary/20 border-primary text-primary" : ""}`}
            >
              {locating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Navigation className="w-3.5 h-3.5" />
              )}
              {locating ? "Locating..." : sortMode === "nearMe" ? "Sorted by: Near Me" : "Near Me"}
            </Button>
          </div>
        </motion.div>

        {/* Stats bar */}
        {stats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="relative z-10 mt-8 flex gap-6 sm:gap-10 text-center px-4"
          >
            {[
              { icon: Building, label: "Properties", value: stats.totalProperties },
              { icon: Star, label: "Reviews", value: stats.totalReviews },
              { icon: Shield, label: "Reliable", value: stats.reliableCount },
              { icon: TrendingUp, label: "Avg Trust", value: `${Math.round(stats.averageTrustScore)}%` },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="text-white">
                <div className="flex items-center justify-center gap-1 text-xl sm:text-2xl font-bold">
                  <Icon className="w-4 h-4 text-primary" />
                  <span>{value}</span>
                </div>
                <div className="text-white/60 text-xs">{label}</div>
              </div>
            ))}
          </motion.div>
        )}
      </div>

      {/* Listings */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <div>
            <h2 className="text-xl font-bold text-foreground">
              {isLoading ? "Loading..." : `${sortedProperties?.length ?? 0} Properties`}
              {hasActiveFilters && <span className="text-primary"> (filtered)</span>}
            </h2>
            <p className="text-muted-foreground text-sm">Student-reviewed PGs near VIT</p>
          </div>

          {/* Sort controls */}
          <div className="flex flex-wrap items-center gap-2">
            {(["nearCollege", "rentAsc", "rentDesc"] as SortMode[]).map((mode) => {
              const labels: Record<string, string> = {
                nearCollege: "Nearest to VIT",
                rentAsc: "Rent: Low to High",
                rentDesc: "Rent: High to Low",
              };
              return (
                <button
                  key={mode}
                  onClick={() => setSortMode(sortMode === mode ? "default" : mode)}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                    sortMode === mode
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-muted-foreground border-border hover:border-primary/50"
                  }`}
                >
                  {labels[mode]}
                </button>
              );
            })}
            {(hasActiveFilters || sortMode !== "default") && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClearFilters}
                className="gap-1.5 text-muted-foreground hover:text-foreground text-xs"
              >
                <X className="w-3 h-3" />
                Clear all
              </Button>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-80 rounded-xl" />
            ))}
          </div>
        ) : sortedProperties && sortedProperties.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {sortedProperties.map((property, index) => (
              <PropertyCard key={property.id} property={property} index={index} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-secondary rounded-2xl mx-auto mb-4 flex items-center justify-center">
              <Building className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-foreground font-medium mb-2">No properties found</h3>
            <p className="text-muted-foreground text-sm">Try adjusting your filters or search terms</p>
            {hasActiveFilters && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleClearFilters}
                className="mt-4"
              >
                Clear filters
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
