import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLogin, useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Home, Eye, EyeOff, User, Mail, Lock, Copy } from "lucide-react";

const authSchema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type AuthForm = z.infer<typeof authSchema>;

export function Login() {
  const { login } = useAuth();
  const [, navigate] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [newAnonymousId, setNewAnonymousId] = useState<string | null>(null);

  const loginMutation = useLogin();
  const registerMutation = useRegister();

  const loginForm = useForm<AuthForm>({ resolver: zodResolver(authSchema) });
  const registerForm = useForm<AuthForm>({ resolver: zodResolver(authSchema) });

  const handleLogin = async (data: AuthForm) => {
    try {
      const res = await loginMutation.mutateAsync({ data });
      login(res.user as any, res.token);
      toast.success(`Welcome back, ${res.user.anonymousId}`);
      navigate("/");
    } catch (err: any) {
      toast.error(err?.response?.data?.error || "Login failed. Check your credentials.");
    }
  };

  const handleRegister = async (data: AuthForm) => {
    try {
      const res = await registerMutation.mutateAsync({ data });
      setNewAnonymousId(res.user.anonymousId);
      login(res.user as any, res.token);
      toast.success("Account created successfully!");
    } catch (err: any) {
      toast.error(err?.response?.data?.error || "Registration failed. Email may already be in use.");
    }
  };

  if (newAnonymousId) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 pt-20" style={{
        backgroundImage: "url(/college-bg.png)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}>
        <div className="absolute inset-0 bg-black/75" />
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 bg-card border border-border rounded-2xl p-8 max-w-sm w-full text-center"
        >
          <div className="w-16 h-16 bg-primary/20 rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <User className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Welcome to AntiGravity</h2>
          <p className="text-muted-foreground text-sm mb-6">Your anonymous identity has been created.</p>

          <div className="bg-secondary/50 rounded-xl p-4 mb-6">
            <p className="text-xs text-muted-foreground mb-1">Your Anonymous ID</p>
            <div className="flex items-center justify-center gap-2">
              <code className="text-2xl font-bold text-primary font-mono">{newAnonymousId}</code>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(newAnonymousId);
                  toast.success("Copied!");
                }}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              This is your identity on AntiGravity. Reviews you post will show this ID — your real name is never shown.
            </p>
          </div>

          <Button
            className="w-full bg-primary text-primary-foreground"
            onClick={() => navigate("/")}
          >
            Start Exploring
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 pt-20 relative" style={{
      backgroundImage: "url(/college-bg.png)",
      backgroundSize: "cover",
      backgroundPosition: "center",
    }}>
      <div className="absolute inset-0 bg-black/75" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md"
      >
        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-primary rounded-xl mx-auto mb-3 flex items-center justify-center">
            <Home className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-white">AntiGravity Housing</h1>
          <p className="text-white/60 text-sm mt-1">Sign in to post anonymous reviews</p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-2xl">
          <Tabs defaultValue="login">
            <TabsList className="w-full mb-6 bg-secondary/50">
              <TabsTrigger value="login" className="flex-1">Login</TabsTrigger>
              <TabsTrigger value="register" className="flex-1">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      {...loginForm.register("email")}
                      placeholder="your@email.com"
                      className="pl-9 bg-secondary/50 border-border"
                    />
                  </div>
                  {loginForm.formState.errors.email && (
                    <p className="text-red-400 text-xs">{loginForm.formState.errors.email.message}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      {...loginForm.register("password")}
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      className="pl-9 pr-9 bg-secondary/50 border-border"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {loginForm.formState.errors.password && (
                    <p className="text-red-400 text-xs">{loginForm.formState.errors.password.message}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Signing in..." : "Sign In"}
                </Button>

                <div className="bg-secondary/30 rounded-lg p-3 mt-3">
                  <p className="text-xs text-muted-foreground text-center">Demo moderator: <code className="text-foreground">moderator@vit.edu</code> / <code className="text-foreground">mod123</code></p>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      {...registerForm.register("email")}
                      placeholder="your@email.com"
                      className="pl-9 bg-secondary/50 border-border"
                    />
                  </div>
                  {registerForm.formState.errors.email && (
                    <p className="text-red-400 text-xs">{registerForm.formState.errors.email.message}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-sm text-muted-foreground">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      {...registerForm.register("password")}
                      type="password"
                      placeholder="Min 6 characters"
                      className="pl-9 bg-secondary/50 border-border"
                    />
                  </div>
                  {registerForm.formState.errors.password && (
                    <p className="text-red-400 text-xs">{registerForm.formState.errors.password.message}</p>
                  )}
                </div>

                <div className="bg-secondary/30 rounded-lg p-3 text-xs text-muted-foreground">
                  A random anonymous ID (like <code className="text-foreground">User#A72X</code>) will be assigned to you. Your real identity is never revealed.
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? "Creating account..." : "Create Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </motion.div>
    </div>
  );
}
