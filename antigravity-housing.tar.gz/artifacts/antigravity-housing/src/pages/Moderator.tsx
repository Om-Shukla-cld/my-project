import { motion } from "framer-motion";
import { Shield, Check, X, Trash2, Flag, AlertTriangle, Clock } from "lucide-react";
import {
  useGetPendingReviews,
  useGetReports,
  useApproveReview,
  useRejectReview,
  useDeleteProperty,
  getGetPendingReviewsQueryKey,
  getGetReportsQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { StarRating } from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export function Moderator() {
  const { isModerator } = useAuth();
  const queryClient = useQueryClient();

  const { data: pendingReviews, isLoading: reviewsLoading } = useGetPendingReviews();
  const { data: reports, isLoading: reportsLoading } = useGetReports();
  const approveMutation = useApproveReview();
  const rejectMutation = useRejectReview();
  const deleteMutation = useDeleteProperty();

  const handleApprove = async (id: number) => {
    try {
      await approveMutation.mutateAsync({ id });
      await queryClient.invalidateQueries({ queryKey: getGetPendingReviewsQueryKey() });
      toast.success("Review approved and published.");
    } catch {
      toast.error("Failed to approve review.");
    }
  };

  const handleReject = async (id: number) => {
    try {
      await rejectMutation.mutateAsync({ id });
      await queryClient.invalidateQueries({ queryKey: getGetPendingReviewsQueryKey() });
      toast.success("Review rejected.");
    } catch {
      toast.error("Failed to reject review.");
    }
  };

  const handleDeleteProperty = async (id: number) => {
    if (!confirm("Are you sure you want to delete this listing? This cannot be undone.")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Property deleted.");
    } catch {
      toast.error("Failed to delete property.");
    }
  };

  if (!isModerator) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-500/20 rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
          <p className="text-muted-foreground text-sm mb-4">
            This dashboard is only accessible to moderators.
          </p>
          <Link href="/">
            <Button variant="outline">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 px-4 pb-12">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Moderator Dashboard</h1>
              <p className="text-muted-foreground text-sm">Review and manage content</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-amber-400">{pendingReviews?.length ?? 0}</div>
              <div className="text-xs text-muted-foreground mt-1">Pending Reviews</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-red-400">{reports?.length ?? 0}</div>
              <div className="text-xs text-muted-foreground mt-1">Reports</div>
            </div>
          </div>

          <Tabs defaultValue="reviews">
            <TabsList className="bg-secondary/50 mb-4">
              <TabsTrigger value="reviews" className="gap-2">
                <Clock className="w-3.5 h-3.5" />
                Pending Reviews
                {pendingReviews && pendingReviews.length > 0 && (
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                    {pendingReviews.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="reports" className="gap-2">
                <Flag className="w-3.5 h-3.5" />
                Reports
                {reports && reports.length > 0 && (
                  <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
                    {reports.length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="reviews">
              {reviewsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
                </div>
              ) : pendingReviews && pendingReviews.length > 0 ? (
                <div className="space-y-4">
                  {pendingReviews.map((review, index) => (
                    <motion.div
                      key={review.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.06 }}
                      className="bg-card border border-border rounded-xl p-5"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <code className="text-sm font-mono font-medium text-primary">
                              {review.anonymousId}
                            </code>
                            <StarRating rating={review.rating} size="sm" />
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Property: <span className="text-foreground font-medium">{review.propertyName}</span>
                          </p>
                          {review.rentPaid && (
                            <p className="text-xs text-muted-foreground">
                              Rent paid: ₹{review.rentPaid.toLocaleString()}/mo
                            </p>
                          )}
                        </div>
                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                          Pending
                        </Badge>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-3 mb-4">
                        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
                          <p className="text-xs text-emerald-400 font-medium mb-1">Pros</p>
                          <p className="text-sm text-foreground/90">{review.pros}</p>
                        </div>
                        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                          <p className="text-xs text-red-400 font-medium mb-1">Cons</p>
                          <p className="text-sm text-foreground/90">{review.cons}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApprove(review.id)}
                          disabled={approveMutation.isPending}
                          className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          <Check className="w-3.5 h-3.5" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleReject(review.id)}
                          disabled={rejectMutation.isPending}
                          className="gap-2 border-red-500/40 text-red-400 hover:bg-red-500/10"
                        >
                          <X className="w-3.5 h-3.5" />
                          Reject
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteProperty(review.propertyId)}
                          disabled={deleteMutation.isPending}
                          className="gap-2 text-muted-foreground hover:text-red-400 ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Delete Listing
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="w-12 h-12 bg-emerald-500/20 rounded-xl mx-auto mb-3 flex items-center justify-center">
                    <Check className="w-6 h-6 text-emerald-400" />
                  </div>
                  <p className="text-muted-foreground text-sm">No pending reviews. All caught up!</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="reports">
              {reportsLoading ? (
                <div className="space-y-3">
                  {[1, 2].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
                </div>
              ) : reports && reports.length > 0 ? (
                <div className="space-y-3">
                  {reports.map((report, index) => (
                    <motion.div
                      key={report.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.06 }}
                      className="bg-card border border-border rounded-xl p-4"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex flex-wrap gap-2 items-center mb-2">
                            <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
                              Report #{report.id}
                            </Badge>
                            {report.reviewId && (
                              <span className="text-xs text-muted-foreground">
                                Review ID: {report.reviewId}
                              </span>
                            )}
                            {report.propertyId && (
                              <span className="text-xs text-muted-foreground">
                                Property ID: {report.propertyId}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-foreground">{report.reason}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(report.createdAt).toLocaleDateString("en-IN", {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                            })}
                          </p>
                        </div>
                        {report.propertyId && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteProperty(report.propertyId!)}
                            className="gap-2 text-muted-foreground hover:text-red-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Delete
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="w-12 h-12 bg-emerald-500/20 rounded-xl mx-auto mb-3 flex items-center justify-center">
                    <Flag className="w-6 h-6 text-emerald-400" />
                  </div>
                  <p className="text-muted-foreground text-sm">No reports filed. Community is clean!</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
