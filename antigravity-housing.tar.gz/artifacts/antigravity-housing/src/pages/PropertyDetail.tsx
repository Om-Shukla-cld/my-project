import { useState } from "react";
import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { MapPin, ArrowLeft, ThumbsUp, ThumbsDown, Flag, Plus, Calendar, BedDouble, School } from "lucide-react";
import { useGetProperty, useGetReviews, useCreateReport } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { TrustBadge } from "@/components/TrustBadge";
import { StarRating } from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export function PropertyDetail() {
  const { id } = useParams<{ id: string }>();
  const propertyId = parseInt(id, 10);
  const { isAuthenticated } = useAuth();
  const [reportingReviewId, setReportingReviewId] = useState<number | null>(null);

  const { data: property, isLoading: propLoading } = useGetProperty(propertyId, {
    query: { enabled: !!propertyId },
  });
  const { data: reviews, isLoading: reviewsLoading } = useGetReviews(propertyId, {
    query: { enabled: !!propertyId },
  });
  const reportMutation = useCreateReport();

  const handleReport = async (reviewId: number) => {
    setReportingReviewId(reviewId);
    try {
      await reportMutation.mutateAsync({
        data: { reviewId, reason: "Suspicious or fake review" },
      });
      toast.success("Report filed. Moderators will review it.");
    } catch {
      toast.error("Failed to file report. Please try again.");
    } finally {
      setReportingReviewId(null);
    }
  };

  if (propLoading) {
    return (
      <div className="min-h-screen pt-20 px-4 max-w-4xl mx-auto">
        <Skeleton className="h-8 w-48 mb-6" />
        <Skeleton className="h-64 w-full rounded-xl mb-6" />
        <Skeleton className="h-40 w-full rounded-xl" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold text-foreground mb-2">Property not found</h2>
          <Link href="/">
            <Button variant="outline">Back to listings</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      {/* Hero image */}
      <div className="relative h-72 bg-secondary overflow-hidden">
        {property.images && property.images.length > 0 ? (
          <img
            src={property.images[0]}
            alt={property.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-secondary to-muted" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-black/30 to-transparent" />

        <div className="absolute bottom-0 left-0 right-0 px-4 sm:px-6 pb-6 max-w-4xl mx-auto">
          <Link href="/">
            <Button
              variant="ghost"
              size="sm"
              className="mb-4 text-white/80 hover:text-white hover:bg-white/10 gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to listings
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Property header */}
          <div className="bg-card border border-border rounded-2xl p-6 mb-6">
            <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-1">{property.name}</h1>
                <div className="flex items-center gap-1 text-muted-foreground text-sm">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{property.address}</span>
                </div>
              </div>
              <TrustBadge
                score={property.trustScore}
                label={property.trustLabel}
                size="lg"
              />
            </div>

            <div className="flex flex-wrap gap-6 mb-5">
              <div>
                <span className="text-3xl font-bold text-primary">
                  ₹{property.rent.toLocaleString()}
                </span>
                <span className="text-muted-foreground text-sm">/month</span>
              </div>
              <div className="flex flex-col justify-center">
                <div className="flex items-center gap-2">
                  <StarRating rating={Math.round(property.averageRating)} size="md" />
                  <span className="font-semibold text-foreground">
                    {property.averageRating > 0 ? property.averageRating.toFixed(1) : "N/A"}
                  </span>
                </div>
                <span className="text-muted-foreground text-xs">
                  {property.reviewCount} review{property.reviewCount !== 1 ? "s" : ""}
                </span>
              </div>
              {(property as any).rooms != null && (
                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-1.5 text-foreground font-semibold">
                    <BedDouble className="w-4 h-4 text-muted-foreground" />
                    {(property as any).rooms} {(property as any).rooms === 1 ? "Room" : "Rooms"}
                  </div>
                  <span className="text-muted-foreground text-xs">Sharing</span>
                </div>
              )}
              {(property as any).distanceFromCollege != null && (
                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
                    <School className="w-4 h-4" />
                    {(property as any).distanceFromCollege < 1
                      ? `${Math.round((property as any).distanceFromCollege * 1000)}m`
                      : `${(property as any).distanceFromCollege} km`}
                  </div>
                  <span className="text-muted-foreground text-xs">from VIT</span>
                </div>
              )}
            </div>

            {property.amenities && property.amenities.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-2 uppercase tracking-wide font-medium">Amenities</p>
                <div className="flex flex-wrap gap-2">
                  {property.amenities.map((a) => (
                    <Badge
                      key={a}
                      variant="secondary"
                      className="text-xs bg-secondary/60 text-foreground"
                    >
                      {a}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Trust Score Explanation */}
          <div className="bg-card border border-border rounded-2xl p-5 mb-6">
            <h2 className="font-semibold text-foreground mb-3 flex items-center gap-2">
              Trust Score Breakdown
            </h2>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-secondary/40 rounded-xl p-3">
                <div className="text-xl font-bold text-foreground">{property.averageRating > 0 ? property.averageRating.toFixed(1) : "0"}/5</div>
                <div className="text-xs text-muted-foreground">Avg Rating</div>
              </div>
              <div className="bg-secondary/40 rounded-xl p-3">
                <div className="text-xl font-bold text-foreground">{property.reviewCount}</div>
                <div className="text-xs text-muted-foreground">Reviews</div>
              </div>
              <div className="bg-secondary/40 rounded-xl p-3">
                <div className={`text-xl font-bold ${property.trustScore >= 80 ? "text-emerald-400" : property.trustScore >= 50 ? "text-amber-400" : "text-red-400"}`}>
                  {property.trustScore}
                </div>
                <div className="text-xs text-muted-foreground">Trust Score</div>
              </div>
            </div>
          </div>

          {/* Reviews */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-semibold text-foreground">
                Student Reviews ({reviews?.length ?? 0})
              </h2>
              {isAuthenticated ? (
                <Link href={`/add-review/${property.id}`}>
                  <Button size="sm" className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
                    <Plus className="w-3.5 h-3.5" />
                    Add Review
                  </Button>
                </Link>
              ) : (
                <Link href="/login">
                  <Button size="sm" variant="outline" className="gap-2">
                    Login to Review
                  </Button>
                </Link>
              )}
            </div>

            {reviewsLoading ? (
              <div className="space-y-3">
                {[1, 2].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
              </div>
            ) : reviews && reviews.length > 0 ? (
              <div className="space-y-4">
                {reviews.map((review, index) => (
                  <motion.div
                    key={review.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.06 }}
                    className="bg-secondary/30 rounded-xl p-4 border border-border/50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                          <span className="text-primary font-bold text-xs">
                            {review.anonymousId.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <span className="font-mono text-sm font-medium text-foreground">
                            {review.anonymousId}
                          </span>
                          {review.rentPaid && (
                            <span className="text-xs text-muted-foreground ml-2">
                              Paid ₹{review.rentPaid.toLocaleString()}/mo
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <StarRating rating={review.rating} size="sm" />
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          {new Date(review.createdAt).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
                        </div>
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-3 mt-3">
                      <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-medium mb-1.5">
                          <ThumbsUp className="w-3.5 h-3.5" />
                          Pros
                        </div>
                        <p className="text-sm text-foreground/90 leading-relaxed">{review.pros}</p>
                      </div>
                      <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-1.5 text-red-400 text-xs font-medium mb-1.5">
                          <ThumbsDown className="w-3.5 h-3.5" />
                          Cons
                        </div>
                        <p className="text-sm text-foreground/90 leading-relaxed">{review.cons}</p>
                      </div>
                    </div>

                    {isAuthenticated && (
                      <div className="flex justify-end mt-2">
                        <button
                          onClick={() => handleReport(review.id)}
                          disabled={reportingReviewId === review.id}
                          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-red-400 transition-colors"
                        >
                          <Flag className="w-3 h-3" />
                          {reportingReviewId === review.id ? "Reporting..." : "Report"}
                        </button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="w-12 h-12 bg-secondary rounded-xl mx-auto mb-3 flex items-center justify-center">
                  <ThumbsUp className="w-6 h-6 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground text-sm">No reviews yet.</p>
                <p className="text-muted-foreground text-xs mt-1">Be the first to review this property.</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
