export function calculateTrustScore(
  averageRating: number,
  reviewCount: number,
  reportCount: number
): number {
  if (reviewCount === 0) return 50;

  const ratingScore = (averageRating / 5) * 60;
  const reviewBonus = Math.min(reviewCount * 3, 30);
  const reportPenalty = Math.min(reportCount * 5, 20);

  const score = Math.max(0, Math.min(100, ratingScore + reviewBonus - reportPenalty));
  return Math.round(score);
}

export function getTrustLabel(score: number): "Reliable" | "Average" | "Risky" {
  if (score >= 80) return "Reliable";
  if (score >= 50) return "Average";
  return "Risky";
}
