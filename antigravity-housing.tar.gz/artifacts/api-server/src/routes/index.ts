import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import propertiesRouter from "./properties";
import reviewsRouter from "./reviews";
import reportsRouter from "./reports";
import moderationRouter from "./moderation";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(propertiesRouter);
router.use(reviewsRouter);
router.use(reportsRouter);
router.use(moderationRouter);

export default router;
