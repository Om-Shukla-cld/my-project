import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, reviewsTable, reportsTable, propertiesTable } from "@workspace/db";
import { ApproveReviewParams, RejectReviewParams, DeletePropertyParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/moderation/reviews", async (_req, res): Promise<void> => {
  const reviews = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.status, "pending"))
    .orderBy(reviewsTable.createdAt);

  const properties = await db.select().from(propertiesTable);
  const propertyMap = new Map(properties.map((p) => [p.id, p.name]));

  res.json(
    reviews.map((r) => ({
      ...r,
      propertyName: propertyMap.get(r.propertyId) ?? "Unknown Property",
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

router.get("/moderation/reports", async (_req, res): Promise<void> => {
  const reports = await db
    .select()
    .from(reportsTable)
    .orderBy(reportsTable.createdAt);

  res.json(
    reports.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

router.post("/moderation/reviews/:id/approve", async (req, res): Promise<void> => {
  const params = ApproveReviewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [review] = await db
    .update(reviewsTable)
    .set({ status: "approved" })
    .where(eq(reviewsTable.id, params.data.id))
    .returning();

  if (!review) {
    res.status(404).json({ error: "Review not found" });
    return;
  }

  res.json({ message: "Review approved" });
});

router.post("/moderation/reviews/:id/reject", async (req, res): Promise<void> => {
  const params = RejectReviewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [review] = await db
    .update(reviewsTable)
    .set({ status: "rejected" })
    .where(eq(reviewsTable.id, params.data.id))
    .returning();

  if (!review) {
    res.status(404).json({ error: "Review not found" });
    return;
  }

  res.json({ message: "Review rejected" });
});

router.delete("/moderation/properties/:id", async (req, res): Promise<void> => {
  const params = DeletePropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [property] = await db
    .delete(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id))
    .returning();

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  res.json({ message: "Property deleted" });
});

export default router;
