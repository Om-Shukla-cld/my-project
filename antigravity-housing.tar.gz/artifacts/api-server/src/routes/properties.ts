import { Router, type IRouter } from "express";
import { eq, and, gte, lte, ilike, or } from "drizzle-orm";
import { db, propertiesTable, reviewsTable, reportsTable } from "@workspace/db";
import { CreatePropertyBody, ListPropertiesQueryParams } from "@workspace/api-zod";
import { calculateTrustScore, getTrustLabel } from "../lib/trustScore";

const router: IRouter = Router();

// VIT Vellore main campus coordinates
const VIT_LAT = 12.9696;
const VIT_LNG = 79.1559;

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

async function buildPropertyWithStats(property: typeof propertiesTable.$inferSelect) {
  const reviews = await db
    .select()
    .from(reviewsTable)
    .where(and(eq(reviewsTable.propertyId, property.id), eq(reviewsTable.status, "approved")));

  const reports = await db
    .select()
    .from(reportsTable)
    .where(eq(reportsTable.propertyId, property.id));

  const reviewCount = reviews.length;
  const averageRating =
    reviewCount > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviewCount
      : 0;

  const trustScore = calculateTrustScore(averageRating, reviewCount, reports.length);
  const trustLabel = getTrustLabel(trustScore);

  const distanceFromCollege =
    property.latitude != null && property.longitude != null
      ? haversineKm(VIT_LAT, VIT_LNG, property.latitude, property.longitude)
      : null;

  return {
    ...property,
    distanceFromCollege,
    trustScore,
    trustLabel,
    averageRating: Math.round(averageRating * 10) / 10,
    reviewCount,
  };
}

router.get("/properties", async (req, res): Promise<void> => {
  const params = ListPropertiesQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { search, minRent, maxRent } = params.data;

  let query = db.select().from(propertiesTable).$dynamic();

  const conditions = [];
  if (search) {
    conditions.push(
      or(
        ilike(propertiesTable.name, `%${search}%`),
        ilike(propertiesTable.address, `%${search}%`)
      )
    );
  }
  if (minRent !== undefined) {
    conditions.push(gte(propertiesTable.rent, minRent));
  }
  if (maxRent !== undefined) {
    conditions.push(lte(propertiesTable.rent, maxRent));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const properties = await query;
  const enriched = await Promise.all(properties.map(buildPropertyWithStats));

  res.json(enriched);
});

router.get("/properties/stats/summary", async (_req, res): Promise<void> => {
  const properties = await db.select().from(propertiesTable);
  const allReviews = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.status, "approved"));

  const enriched = await Promise.all(properties.map(buildPropertyWithStats));

  const totalProperties = properties.length;
  const totalReviews = allReviews.length;
  const averageTrustScore =
    enriched.length > 0
      ? enriched.reduce((sum, p) => sum + p.trustScore, 0) / enriched.length
      : 0;
  const reliableCount = enriched.filter((p) => p.trustLabel === "Reliable").length;
  const riskyCount = enriched.filter((p) => p.trustLabel === "Risky").length;

  const rents = properties.map((p) => p.rent);
  const rentRange = {
    min: rents.length > 0 ? Math.min(...rents) : 0,
    max: rents.length > 0 ? Math.max(...rents) : 0,
  };

  res.json({
    totalProperties,
    totalReviews,
    averageTrustScore: Math.round(averageTrustScore),
    reliableCount,
    riskyCount,
    rentRange,
  });
});

router.get("/properties/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid property ID" });
    return;
  }

  const [property] = await db
    .select()
    .from(propertiesTable)
    .where(eq(propertiesTable.id, id));

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  const enriched = await buildPropertyWithStats(property);
  res.json(enriched);
});

router.post("/properties", async (req, res): Promise<void> => {
  const parsed = CreatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [property] = await db
    .insert(propertiesTable)
    .values({
      ...parsed.data,
      amenities: parsed.data.amenities ?? [],
      images: parsed.data.images ?? [],
    })
    .returning();

  const enriched = await buildPropertyWithStats(property);
  res.status(201).json(enriched);
});

export default router;
