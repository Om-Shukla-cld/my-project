import { Router, type IRouter } from "express";
import { db, reportsTable } from "@workspace/db";
import { CreateReportBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = CreateReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await db.insert(reportsTable).values({
    reviewId: parsed.data.reviewId ?? null,
    propertyId: parsed.data.propertyId ?? null,
    reason: parsed.data.reason,
  });

  res.status(201).json({ message: "Report filed successfully" });
});

export default router;
