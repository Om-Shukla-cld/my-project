import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, reviewsTable, usersTable } from "@workspace/db";
import { CreateReviewBody, GetReviewsParams } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.get("/reviews/:propertyId", async (req, res): Promise<void> => {
  const params = GetReviewsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const reviews = await db
    .select()
    .from(reviewsTable)
    .where(
      and(
        eq(reviewsTable.propertyId, params.data.propertyId),
        eq(reviewsTable.status, "approved")
      )
    )
    .orderBy(reviewsTable.createdAt);

  res.json(
    reviews.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

router.post("/reviews", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateReviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const user = (req as any).user;

  const [review] = await db
    .insert(reviewsTable)
    .values({
      propertyId: parsed.data.propertyId,
      userId: user.id,
      anonymousId: user.anonymousId,
      rating: parsed.data.rating,
      pros: parsed.data.pros,
      cons: parsed.data.cons,
      rentPaid: parsed.data.rentPaid ?? null,
      status: "pending",
    })
    .returning();

  res.status(201).json({
    ...review,
    createdAt: review.createdAt.toISOString(),
  });
});

export default router;
